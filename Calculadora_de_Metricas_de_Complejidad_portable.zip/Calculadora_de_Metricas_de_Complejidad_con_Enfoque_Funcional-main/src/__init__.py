"""Paquete principal de la calculadora de métricas de complejidad."""
