"""Suite de pruebas portable (compatible con unittest y pytest)."""
