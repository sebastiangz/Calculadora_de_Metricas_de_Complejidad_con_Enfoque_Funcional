from pathlib import Path
import tempfile
from textwrap import dedent
import unittest

from tests._entorno import requiere_radon

from src.analizador import analizar_archivo_py
from src.validacion import obtener_complejidad_radon


class TestValidacion(unittest.TestCase):
    @requiere_radon
    def test_complejidad_coincide_con_radon(self):
        casos = [
            (
                "funcion-simple",
                """
                def saludar():
                    return "Hola"
                """,
                {"saludar": 1},
            ),
            (
                "if",
                """
                def evaluar(x):
                    if x > 0:
                        return x
                    return 0
                """,
                None,
            ),
            (
                "if-anidado",
                """
                def evaluar(x, y):
                    if x > 0:
                        if y > 0:
                            return 1
                        return 2
                    return 3
                """,
                None,
            ),
            (
                "varias-funciones-for-y-booleano",
                """
                def saludar():
                    return "Hola"

                async def contar_positivos(numeros, limite):
                    total = 0
                    for numero in numeros:
                        if numero > 0 and numero < limite:
                            total += 1
                    return total
                """,
                None,
            ),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            for idx, (nombre_caso, codigo, complejidad_esperada) in enumerate(casos):
                with self.subTest(caso=nombre_caso):
                    codigo_limpio = dedent(codigo)
                    archivo = tmp_path / f"codigo_prueba_{idx}.py"
                    archivo.write_text(codigo_limpio, encoding="utf-8")

                    complejidad_propia = {
                        metrica.name: metrica.cyclomatic_complexity
                        for metrica in analizar_archivo_py(str(archivo))
                    }
                    complejidad_radon = obtener_complejidad_radon(codigo_limpio)

                    self.assertEqual(complejidad_propia, complejidad_radon)
                    if complejidad_esperada is not None:
                        self.assertEqual(complejidad_propia, complejidad_esperada)


if __name__ == "__main__":
    unittest.main()
