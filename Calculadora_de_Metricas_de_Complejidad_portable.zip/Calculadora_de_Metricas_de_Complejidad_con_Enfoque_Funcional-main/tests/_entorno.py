"""Configuración portable del entorno de pruebas (rutas, codificación y dependencias opcionales)."""
from pathlib import Path
import sys
import unittest

RAIZ = Path(__file__).resolve().parents[1]
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

try:
    import radon  # noqa: F401
    from radon.metrics import h_visit  # noqa: F401
    RADON_DISPONIBLE = True
except ImportError:
    h_visit = None
    RADON_DISPONIBLE = False


def requiere_radon(func):
    """Omite la prueba de forma limpia si la librería opcional 'radon' no está instalada."""
    return unittest.skipUnless(RADON_DISPONIBLE, "Dependencia opcional 'radon' no instalada")(func)
