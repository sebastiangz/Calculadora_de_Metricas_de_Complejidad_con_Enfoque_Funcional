import ast
import json
import os
import subprocess
import sys
import tempfile
import unittest
from html import escape
from math import log2
from pathlib import Path
from textwrap import indent
from xml.etree import ElementTree

from tests._entorno import RADON_DISPONIBLE, RAIZ, h_visit, requiere_radon

from src.analizador import analizar_archivo_py
from src.metricas import calcular_halstead, profundidad
from src.reportes import a_html, a_json, a_texto, analizar


def _env_utf8() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


class TestAuditoria(unittest.TestCase):
    def test_metricas_por_construccion(self):
        casos = [
            ("base", "return 0", 1, 1, 0),
            ("if", "if x: return 1", 2, 2, 1),
            ("if-else", "if x: return 1\nelse: return 0", 2, 2, 2),
            ("elif", "if x: return 1\nelif y: return 0", 3, 3, 2),
            ("if-anidado", "if x:\n    if y: return 1", 3, 3, 3),
            ("for", "for i in x: pass", 2, 2, 1),
            ("while-continue", "while x: continue", 2, 2, 2),
            ("async-for", "async for i in x: pass", 2, 2, 1),
            ("and-or", "return (x and y) or z", 3, 3, 2),
            ("except", "try: return x\nexcept ValueError: return 0", 2, 2, 1),
            ("match", "match x:\n    case 0: return 0\n    case _: return 1", 3, 2, 1),
            ("for-else", "for i in x: pass\nelse: pass", 2, 3, 2),
            ("lambda", "return lambda y: y and x", 1, 2, 0),
        ]
        for nombre_caso, cuerpo, cc, radon_esperado, cognitiva in casos:
            with self.subTest(caso=nombre_caso):
                codigo = "async def f(x, y, z):\n" + indent(cuerpo, "    ")
                (resultado,) = analizar(codigo).funciones
                self.assertEqual((resultado.cc_propia, resultado.cognitiva), (cc, cognitiva))
                if RADON_DISPONIBLE:
                    self.assertEqual(resultado.cc_radon, radon_esperado)
                    self.assertIs(resultado.coincide, cc == radon_esperado)
                else:
                    self.assertIsNone(resultado.cc_radon)
                    self.assertIsNone(resultado.coincide)

    def test_parser_ignora_la_cabecera_y_separa_ambitos(self):
        codigo = """@decorador or alternativo
def f(x=(1 and 2)):
    def f():
        if x:
            return 1
    return f()
"""
        with tempfile.TemporaryDirectory() as tmp:
            ruta = Path(tmp) / "fuente.py"
            ruta.write_text(codigo, encoding="utf-8")
            metricas = analizar_archivo_py(str(ruta))
            self.assertIsInstance(metricas, tuple)
            self.assertEqual(
                [(m.name, m.cyclomatic_complexity, m.lines, m.max_nesting_depth) for m in metricas],
                [("f", 1, 5, 0), ("f", 2, 3, 1)],
            )
            if RADON_DISPONIBLE:
                self.assertEqual([(f.linea, f.cc_radon) for f in analizar(codigo).funciones], [(2, 1), (3, 2)])
            else:
                self.assertEqual([(f.linea, f.cc_radon) for f in analizar(codigo).funciones], [(2, None), (3, None)])
            self.assertEqual(profundidad(ast.parse("if x:\n    pass")), 4)

    def test_halstead_formula_y_operadores_repetidos(self):
        codigo = """def f(x):
    x = x + x
    x += 1
    return -x if 1 < x <= 2 and x and x else 0
"""
        h = calcular_halstead(ast.parse(codigo).body[0])
        self.assertEqual((h.operadores_distintos, h.operandos_distintos), (7, 4))
        self.assertEqual((h.total_operadores, h.total_operandos), (8, 12))
        self.assertEqual((h.vocabulario, h.longitud), (11, 20))
        self.assertAlmostEqual(h.volumen, 20 * log2(11))
        self.assertAlmostEqual(h.dificultad, 10.5)
        self.assertAlmostEqual(h.esfuerzo, 10.5 * 20 * log2(11))

    @requiere_radon
    def test_halstead_coincide_con_radon_en_una_suma(self):
        codigo = "def f(x):\n    return x + 1"
        h = calcular_halstead(ast.parse(codigo).body[0])
        _, referencia = h_visit(codigo).functions[0]
        self.assertEqual((h.operadores_distintos, h.operandos_distintos), (referencia.h1, referencia.h2))
        self.assertEqual((h.total_operadores, h.total_operandos), (referencia.N1, referencia.N2))
        self.assertAlmostEqual(h.volumen, referencia.volume)

    def test_svg_representa_los_mismos_nodos_y_aristas_del_json(self):
        informe = analizar(
            """def f(xs):
    for x in xs:
        if x:
            continue
        break
    return 0

def g():
    pass
""",
            "<&>.py",
        )
        html = a_html(informe)
        self.assertIn(escape(a_texto(informe)), html)
        self.assertIn('id="flecha-cfg-0"', html)
        self.assertIn('id="flecha-cfg-1"', html)
        svg = ElementTree.fromstring(html[html.index("<svg") : html.index("</svg>") + len("</svg>")])
        datos = json.loads(a_json(informe))["funciones"][0]["cfg"]
        ns = "{http://www.w3.org/2000/svg}"
        grupos = svg.findall(f"{ns}g")
        nodos = [g for g in grupos if "data-nodo" in g.attrib]
        aristas = [g for g in grupos if "data-origen" in g.attrib]

        self.assertEqual({int(g.attrib["data-nodo"]) for g in nodos}, {n["id"] for n in datos["nodos"]})
        self.assertLessEqual(
            {"entrada", "salida", "If · L3", "Return · L6"},
            {g.findtext(f"{ns}text") for g in nodos},
        )
        self.assertEqual(
            {
                (int(g.attrib["data-origen"]), int(g.attrib["data-destino"]), g.findtext(f"{ns}title"))
                for g in aristas
            },
            {(a["origen"], a["destino"], a["etiqueta"]) for a in datos["aristas"]},
        )
        self.assertLessEqual(
            {"verdadero", "falso", "iterar", "break", "continue"},
            {g.findtext(f"{ns}title") for g in aristas},
        )
        self.assertTrue(all(g.find(f"{ns}path").get("marker-end") == "url(#flecha-cfg-0)" for g in aristas))

    def test_cli_codigos_y_entradas(self):
        casos = [
            ("sin-argumentos", [], 2, "Uso:"),
            ("demasiados", ["ok.py", "--json", "--html"], 2, "Uso:"),
            ("sin-archivo", ["--json", "--html"], 2, "Uso:"),
            ("inexistente", ["ausente.py"], 1, "no se encontró"),
            ("extension", ["otro.txt"], 1, "extensión .py"),
            ("vacio", ["vacio.py"], 0, "No se encontraron funciones"),
            ("sin-funciones", ["sin_funciones.py"], 0, "No se encontraron funciones"),
            ("contexto", ["break.py", "--json"], 1, "Error de sintaxis en la línea 2"),
            ("codificacion-invalida", ["invalido.py"], 1, "Error"),
            ("codificacion-declarada", ["latin.py", "--json"], 0, '"nombre": "año"'),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            for nombre, contenido in {
                "ok.py": b"def f(): pass\n",
                "otro.txt": b"",
                "vacio.py": b"",
                "sin_funciones.py": b"x = 1\n",
                "break.py": b"def f():\n    break\n",
                "invalido.py": bytes([255]),
                "latin.py": "# coding: latin-1\ndef año(): pass\n".encode("latin-1"),
            }.items():
                (tmp_path / nombre).write_bytes(contenido)

            for nombre_caso, argumentos, estado, mensaje in casos:
                with self.subTest(caso=nombre_caso):
                    resultado = subprocess.run(
                        [sys.executable, str(RAIZ / "main.py"), *argumentos],
                        cwd=tmp_path,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        env=_env_utf8(),
                    )
                    self.assertEqual(resultado.returncode, estado)
                    if estado == 0:
                        self.assertEqual(resultado.stderr, "")
                        self.assertIn(mensaje, resultado.stdout)
                    else:
                        self.assertEqual(resultado.stdout, "")
                        self.assertIn(mensaje, resultado.stderr)


if __name__ == "__main__":
    unittest.main()
