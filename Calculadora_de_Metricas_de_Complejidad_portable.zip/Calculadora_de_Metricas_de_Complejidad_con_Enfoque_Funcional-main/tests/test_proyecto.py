import ast
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from tests._entorno import RADON_DISPONIBLE, RAIZ

from src.cfg import construir_cfg
from src.metricas import calcular_halstead, complejidad_cognitiva, profundidad
from src.reportes import a_html, a_json, analizar


def funcion(codigo):
    return ast.parse(codigo).body[0]


def _env_utf8() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


class TestProyecto(unittest.TestCase):
    def test_cognitiva_anidamiento_y_elif(self):
        nodo = funcion("""def f(x, y):
    if x:
        while y:
            break
    elif y and x:
        return 1
    else:
        return 0
""")
        self.assertEqual(complejidad_cognitiva(nodo), 7)

    def test_metricas_excluyen_ambitos_internos(self):
        nodo = funcion("""def f():
    def interna(x):
        if x + 1:
            return 1
    pass
""")
        self.assertEqual(complejidad_cognitiva(nodo), 0)
        self.assertEqual(calcular_halstead(nodo).volumen, 0)
        self.assertEqual(profundidad(ast.Pass()), 1)
        self.assertEqual(profundidad(ast.parse("pass")), 2)

    def test_halstead_valores_y_formulas(self):
        nodo = funcion("def f(x):\n    return x + x * 2")
        resultado = calcular_halstead(nodo)
        self.assertEqual((resultado.operadores_distintos, resultado.operandos_distintos), (2, 2))
        self.assertEqual((resultado.total_operadores, resultado.total_operandos), (2, 3))
        self.assertEqual((resultado.vocabulario, resultado.longitud), (4, 5))
        self.assertAlmostEqual(resultado.volumen, 10)
        self.assertAlmostEqual(resultado.dificultad, 1.5)
        self.assertAlmostEqual(resultado.esfuerzo, 15)

    def test_cfg_secuencia_if_y_retorno(self):
        grafo = construir_cfg(
            funcion("""def f(x):
    a = 1
    if x:
        return a
    else:
        a = 2
    return a
""")
        )
        ids = {n.linea: n.id for n in grafo.nodos if n.linea is not None}
        enlaces = {(a.origen, a.destino, a.etiqueta) for a in grafo.aristas}
        self.assertEqual(
            enlaces,
            {
                (grafo.entrada, ids[2], "siguiente"),
                (ids[2], ids[3], "siguiente"),
                (ids[3], ids[4], "verdadero"),
                (ids[3], ids[6], "falso"),
                (ids[4], grafo.salida, "return"),
                (ids[6], ids[7], "siguiente"),
                (ids[7], grafo.salida, "return"),
            },
        )

    def test_cfg_bucles_anidados_y_else(self):
        grafo = construir_cfg(
            funcion("""def f(xs):
    for x in xs:
        while x:
            if x == 1:
                break
            continue
    else:
        return 1
""")
        )
        ids = {n.linea: n.id for n in grafo.nodos if n.linea is not None}
        enlaces = {(a.origen, a.destino, a.etiqueta) for a in grafo.aristas}
        self.assertEqual(
            enlaces,
            {
                (grafo.entrada, ids[2], "siguiente"),
                (ids[2], ids[3], "iterar"),
                (ids[2], ids[8], "fin del bucle"),
                (ids[3], ids[4], "iterar"),
                (ids[3], ids[2], "fin del bucle"),
                (ids[4], ids[5], "verdadero"),
                (ids[4], ids[6], "falso"),
                (ids[5], ids[2], "break"),
                (ids[6], ids[3], "continue"),
                (ids[8], grafo.salida, "return"),
            },
        )

    def test_reporte_json_tiene_metricas_cfg_y_referencias_por_linea(self):
        informe = analizar("""def f():
    return 1

def f(x):
    if x:
        return 2
""")
        simple, condicional = json.loads(a_json(informe))["funciones"]
        if RADON_DISPONIBLE:
            self.assertEqual([simple["cc_radon"], condicional["cc_radon"]], [1, 2])
            self.assertIs(condicional["coincide"], True)
        else:
            self.assertEqual([simple["cc_radon"], condicional["cc_radon"]], [None, None])
            self.assertIsNone(condicional["coincide"])
        self.assertEqual(condicional["cognitiva"], 1)
        self.assertEqual(condicional["halstead"]["total_operandos"], 2)
        self.assertTrue(any(a["etiqueta"] == "verdadero" for a in condicional["cfg"]["aristas"]))

    def test_reporte_html_escapa_el_nombre_del_archivo(self):
        html = a_html(analizar("def f(): pass", "<script>&.py"))
        self.assertIn("&lt;script&gt;&amp;.py", html)
        self.assertNotIn("<script>", html)
        self.assertIn("<summary>CFG de f (línea 1)</summary>", html)

    def test_cli_formatos(self):
        with tempfile.TemporaryDirectory() as tmp:
            archivo = Path(tmp) / "ejemplo.py"
            archivo.write_text("def f(x):\n    return x + 1\n", encoding="utf-8")
            main_script = RAIZ / "main.py"
            for opcion in ([], ["--json"], ["--html"]):
                with self.subTest(opcion=opcion):
                    resultado = subprocess.run(
                        [sys.executable, str(main_script), str(archivo), *opcion],
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        env=_env_utf8(),
                        check=True,
                    )
                    self.assertEqual(resultado.stderr, "")
                    if opcion == ["--json"]:
                        datos = json.loads(resultado.stdout)["funciones"][0]
                        self.assertEqual(datos["cc_propia"], 1)
                        if RADON_DISPONIBLE:
                            self.assertIs(datos["coincide"], True)
                        else:
                            self.assertIsNone(datos["coincide"])
                    elif opcion == ["--html"]:
                        self.assertIn("<summary>CFG de f (línea 1)</summary>", resultado.stdout)
                    else:
                        if RADON_DISPONIBLE:
                            self.assertIn("CC propia: 1 | CC Radon: 1 | Coinciden: sí", resultado.stdout)
                        else:
                            self.assertIn("CC propia: 1 | CC Radon: no disponible | Coinciden: no comparable", resultado.stdout)

    def test_cli_falla_con_error_de_sintaxis(self):
        with tempfile.TemporaryDirectory() as tmp:
            archivo = Path(tmp) / "mal.py"
            archivo.write_text("def f(:", encoding="utf-8")
            main_script = RAIZ / "main.py"
            resultado = subprocess.run(
                [sys.executable, str(main_script), str(archivo), "--json"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                env=_env_utf8(),
            )
            self.assertEqual(resultado.returncode, 1)
            self.assertEqual(resultado.stdout, "")
            self.assertIn("Error de sintaxis en la línea 1", resultado.stderr)

    def test_radon_distingue_metodo_y_funcion_interna(self):
        informe = analizar("""class C:
    def f(self):
        def f(x):
            if x:
                return 1
        return f(True)
""")
        if RADON_DISPONIBLE:
            self.assertEqual([(f.linea, f.cc_radon) for f in informe.funciones], [(2, 1), (3, 2)])
        else:
            self.assertEqual([(f.linea, f.cc_radon) for f in informe.funciones], [(2, None), (3, None)])


if __name__ == "__main__":
    unittest.main()
