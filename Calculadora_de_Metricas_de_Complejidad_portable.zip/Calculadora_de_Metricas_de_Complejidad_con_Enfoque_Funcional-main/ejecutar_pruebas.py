#!/usr/bin/env python3
"""Ejecutor portable de pruebas.

Funciona sin dependencias externas usando la biblioteca estándar (`unittest`),
desde cualquier directorio de trabajo y en Windows, Linux o macOS.
"""
from pathlib import Path
import sys
import unittest


def main() -> int:
    raiz = Path(__file__).resolve().parent
    if str(raiz) not in sys.path:
        sys.path.insert(0, str(raiz))

    loader = unittest.TestLoader()
    suite = loader.discover(start_dir=str(raiz / "tests"), pattern="test_*.py", top_level_dir=str(raiz))
    runner = unittest.TextTestRunner(verbosity=2)
    resultado = runner.run(suite)
    return 0 if resultado.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
